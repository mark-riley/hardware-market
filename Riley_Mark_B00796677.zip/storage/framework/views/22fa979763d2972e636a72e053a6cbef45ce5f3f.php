<?php echo e($slot); ?>

<?php /**PATH G:\Final Year\Project\Project Code\hardware-market\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>