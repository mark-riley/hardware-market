

<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        Welcome to our new site!
    </div>
    <div class="card-body">
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div class="col-8">
                <table>
                    <thead>
                        <tr>
                            <td><b>User ID</b></td>
                            <td><b>User Name</b></td>
                            <td><b>User Email</b></td>
                            <td><b>User Email Verified At</b></td>
                            <td><b>User Created At</b></td>
                            <td><b>User Updated At</b></td>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($info->id); ?></td>
                            <td><?php echo e($info->name); ?></td>
                            <td><?php echo e($info->email); ?></td>
                            <td><?php echo e($info->email_verified_at); ?></td>
                            <td><?php echo e($info->created_at); ?></td>
                            <td><?php echo e($info->updated_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Final Year\Project\Project Code\hardware-market\resources\views/my-profile.blade.php ENDPATH**/ ?>