<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        Home!
    </div>
    <div class="card-body">
        <h1 class="card-title">Hardware Market</h1>
        <h4 class="card-text">We hope you enjoy the experience!</h4>
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div class="col-8">
                
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Final Year\Project\Project Code\hardware-market\resources\views/home.blade.php ENDPATH**/ ?>