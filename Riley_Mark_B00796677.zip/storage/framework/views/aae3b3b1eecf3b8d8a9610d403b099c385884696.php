

<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        Edit Listing
    </div>
    <div class="card-body">
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div id="edit listing" class="col-8" style="text-align: left;border-bottom:1px solid #222222;">
                <h4>Edit Listing</h4>

                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form style="font-size: 10pt;" id="editListingForm" action="/edit-listing" method="post">
                <?php echo csrf_field(); ?>
                    <input type="hidden" id="id" name="id" value="<?php echo e($listing->id); ?>"/>
                    <div class="mb-3">
                        <label for="listingName" class="form-label">Listing Name</label>
                        <input type="text" class="form-control" id="listingName" name="listingName" value="<?php echo e($listing->listingName); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="listingPrice" class="form-label">Listing Price</label>
                        <input type="text" class="form-control" id="listingPrice" name="listingPrice" value="<?php echo e($listing->listingPrice); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="listingComponent" class="form-label">Listing Component</label>
                        <input type="text" class="form-control" id="listingComponent" name="listingComponent" value="<?php echo e($listing->listingComponent); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="listingModel" class="form-label">Listing Model</label>
                        <input type="text" class="form-control" id="listingModel" name="listingModel" value="<?php echo e($listing->listingModel); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="listingQuality" class="form-label">Listing Quality</label>
                        <input type="text" class="form-control" id="listingQuality" name="listingQuality" value="<?php echo e($listing->listingQuality); ?>">
                    </div>
            
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <br/>
                    <br/>         
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Final Year\Project\Project Code\hardware-market\resources\views/edit-listing.blade.php ENDPATH**/ ?>