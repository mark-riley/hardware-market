

<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        Admin
    </div>
    <div class="card-body">
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div class="col-8">
                <form style="font-size: 10pt;" id="newComponentForm" action="/add-component" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Final Year\Project\Project Code\hardware-market\resources\views/admin.blade.php ENDPATH**/ ?>