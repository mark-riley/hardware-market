

<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        All Listings
    </div>
    <div class="card-body">
        <div class="row align-items-start">
            <div class="col-1">
            </div>
            <div class="col-10">
                <table class="table">
                    <thead>
                        <tr>
                            <!-- Head -->
                            
                            <th style="width: 25vh"></th>
                            <th>Returned <?php echo e(count($data)); ?> items.</th>

                            <!-- <td>Images</td>
                            <td>Text</td> -->

                            <!-- Basic Table Layout -->
                            <!-- <td><b>Listing ID</b></td>
                            <td><b>Listing Name</b></td>
                            <td><b>Listing Price</b></td>
                            <td><b>Listing Component</b></td>
                            <td><b>Listing Model</b></td>
                            <td><b>Listing Quality</b></td>
                            <td><b>User Name</b></td>
                            <td><b>User ID</b></td>
                            <td><b>Created At</b></td>
                            <td><b>Updated At</b></td> -->
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="height: 25vh">
                                <td style="position: relative;">
                                    <!-- <a href="/listing/<?php echo e($listing->id); ?>"><?php echo e($listing->id); ?></a> -->

                                    <?php
                                        $imageCount = 0;
                                    ?>
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(($image->listingID == $listing->id) && ($imageCount < 1)): ?>
                                            <?php
                                                $imageCount = $imageCount + 1;
                                            ?>
                                            <a href="/listing/<?php echo e($listing->id); ?>"><img src="<?php echo e(asset('/images/'.$image->filePath)); ?>" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); max-height: 25vh; max-width: 25vh; height: auto; width: auto"></a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($imageCount == 0): ?>
                                        <a href="/listing/<?php echo e($listing->id); ?>"><img src="<?php echo e(asset('/images/noImageUploaded.png')); ?>" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); max-height: 25vh; max-width: 25vh; height: auto; width: auto"></a>
                                    <?php endif; ?>
                                </td>
                                <td style="position: relative;">
                                    <div style="word-wrap: break-word;">
                                        <p style="display:inline-block;"><strong><?php echo e($listing->listingName); ?></strong></p>
                                        <br>
                                        <p style="display:inline-block;">£<?php echo e($listing->listingPrice); ?></p>
                                        <br>
                                        <p style="display:inline-block;"><?php echo e($listing->listingQuality); ?></p>
                                        <p style="display:inline-block;"><?php echo e($listing->listingModel); ?></p>
                                        <p style="display:inline-block;"><?php echo e($listing->listingComponent); ?></p>
                                        <?php if($listing->listingDescription != NULL): ?>
                                            <br>
                                            <p style="display:inline-block; word-break: break-word;"><?php echo e($listing->listingDescription); ?></p>
                                        <?php endif; ?>
                                        <br>
                                        <p style="display:inline-block;"><?php echo e($listing->userName); ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <span><?php echo e($data->links()); ?></span>
            </div>
            <div class="col-1">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Final Year\Project\Project Code\hardware-market\resources\views/listings.blade.php ENDPATH**/ ?>