

<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <div class="card-header">
        Welcome to our new site!
    </div>
    <div class="card-body">
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div class="col-8">
                <table>
                    <thead>
                        <tr>
                            <td><b>Listing ID</b></td>
                            <td><b>Listing Name</b></td>
                            <td><b>Listing Price</b></td>
                            <td><b>Listing Component</b></td>
                            <td><b>Listing Model</b></td>
                            <td><b>Listing Quality</b></td>
                            <td><b>User Name</b></td>
                            <td><b>User ID</b></td>
                            <td><b>Created At</b></td>
                            <td><b>Updated At</b></td>
                            <td><b>Delete</b></td>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="/edit-listing/<?php echo e($listing->id); ?>"><?php echo e($listing->id); ?></a></td>
                            <td><?php echo e($listing->listingName); ?></td>
                            <td><?php echo e($listing->listingPrice); ?></td>
                            <td><?php echo e($listing->listingComponent); ?></td>
                            <td><?php echo e($listing->listingModel); ?></td>
                            <td><?php echo e($listing->listingQuality); ?></td>
                            <td><?php echo e($listing->userName); ?></td>
                            <td><?php echo e($listing->userID); ?></td>
                            <td><?php echo e($listing->created_at); ?></td>
                            <td><?php echo e($listing->updated_at); ?></td>
                            <td><a href="/delete/<?php echo e($listing->id); ?>">Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <span><?php echo e($data->links()); ?></span>
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Final Year\Project\Project Code\hardware-market\resources\views/my-listings.blade.php ENDPATH**/ ?>