@extends('layouts.app')

@section('content')
<div class="card text-center">
    <div class="card-header">
        Home!
    </div>
    <div class="card-body">
        <h1 class="card-title">Hardware Market</h1>
        <h4 class="card-text">We hope you enjoy the experience!</h4>
        <div class="row align-items-start">
            <div class="col-2">
            </div>
            <div class="col-8">
                
            </div>
            <div class="col-2">
            </div>
        </div>
    </div>
</div>
@endsection
